A cooperative co-evolutionary algorithm-based feature selection (CCEAFS) framework.
